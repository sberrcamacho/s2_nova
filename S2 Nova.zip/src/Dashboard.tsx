import { useState } from 'react'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  PieChart, Pie, Cell, XAxis, YAxis, Tooltip,
  CartesianGrid, Legend, ResponsiveContainer,
} from 'recharts'
import {
  transactions, budgets, monthlyData, weeklyData,
  balanceHistory, categoryChartData, topCategories,
} from './data'
import type { Transaction } from './data'

import { C } from './theme'

type Page = 'overview' | 'expenses' | 'income' | 'budgets' | 'categories' | 'reports' | 'analytics' | 'users' | 'settings'

// ─── Sidebar Icons ────────────────────────────────────────────────────────────
const SI = {
  Overview: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>,
  Expenses: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><path d="M5 12l7 7 7-7"/></svg>,
  Income: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="19" x2="12" y2="5"/><path d="M5 12l7-7 7 7"/></svg>,
  Budgets: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="3"/><path d="M16 12h.01"/></svg>,
  Categories: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l9 7-9 7-9-7 9-7z"/><path d="M3 15l9 7 9-7"/></svg>,
  Reports: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/></svg>,
  Analytics: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>,
  Users: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>,
  Settings: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>,
  Bell: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>,
  Search: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.textDim} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>,
  TrendUp: () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>,
  TrendDown: () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>,
  Download: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
}

// ─── Shared primitives ────────────────────────────────────────────────────────
function Card({ children, style = {} }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border}`, boxShadow: '0 1px 3px rgba(0,0,0,0.04)', ...style }}>
      {children}
    </div>
  )
}

function StatCard({ label, value, sub, trend, trendUp }: { label: string; value: string; sub?: string; trend?: string; trendUp?: boolean }) {
  return (
    <Card style={{ padding: '20px 22px' }}>
      <p style={{ margin: '0 0 14px', fontSize: 12, color: C.textDim, fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase' }}>{label}</p>
      <p style={{ margin: '0 0 8px', fontSize: 28, fontWeight: 800, letterSpacing: '-0.8px', fontVariantNumeric: 'tabular-nums' }}>{value}</p>
      {trend && (
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 4,
          background: trendUp ? C.greenDim : C.redDim,
          color: trendUp ? C.green : C.red,
          borderRadius: 99, padding: '3px 10px', fontSize: 12, fontWeight: 700,
        }}>
          {trendUp ? <SI.TrendUp /> : <SI.TrendDown />} {trend}
        </span>
      )}
      {sub && !trend && <p style={{ margin: 0, fontSize: 12, color: C.textDim, fontWeight: 500 }}>{sub}</p>}
    </Card>
  )
}

function PageHeader({ title, sub, action }: { title: string; sub?: string; action?: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
      <div>
        <h1 style={{ margin: '0 0 4px', fontSize: 24, fontWeight: 800, letterSpacing: '-0.5px' }}>{title}</h1>
        {sub && <p style={{ margin: 0, fontSize: 14, color: C.textSub, fontWeight: 500 }}>{sub}</p>}
      </div>
      {action}
    </div>
  )
}

function ChartCard({ title, sub, children, action }: { title: string; sub?: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <Card style={{ padding: '22px 24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <p style={{ margin: '0 0 3px', fontSize: 15, fontWeight: 700 }}>{title}</p>
          {sub && <p style={{ margin: 0, fontSize: 12, color: C.textDim, fontWeight: 500 }}>{sub}</p>}
        </div>
        {action}
      </div>
      {children}
    </Card>
  )
}

function Tag({ children, color, bg }: { children: React.ReactNode; color: string; bg: string }) {
  return <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: bg, color, borderRadius: 99, padding: '3px 10px', fontSize: 11, fontWeight: 700 }}>{children}</span>
}

function DBtn({ children, variant = 'primary', onClick }: { children: React.ReactNode; variant?: 'primary' | 'secondary' | 'ghost'; onClick?: () => void }) {
  const s = {
    primary: { background: C.green, color: '#fff', border: 'none' },
    secondary: { background: C.surface, color: C.text, border: `1.5px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.green, border: 'none' },
  }
  return (
    <button onClick={onClick} style={{
      ...s[variant], padding: '9px 18px', borderRadius: 10, cursor: 'pointer',
      fontSize: 13, fontWeight: 700, fontFamily: 'Manrope, sans-serif',
      display: 'flex', alignItems: 'center', gap: 6, transition: 'opacity 0.15s',
    }}>{children}</button>
  )
}

// ─── Tooltip ──────────────────────────────────────────────────────────────────
function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ color: string; name: string; value: number }>; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: '10px 14px', boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }}>
      {label && <p style={{ margin: '0 0 6px', fontSize: 11, color: C.textDim, fontWeight: 600 }}>{label}</p>}
      {payload.map((p, i) => (
        <p key={i} style={{ margin: i < payload.length - 1 ? '0 0 3px' : 0, fontSize: 13, fontWeight: 700 }}>
          <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: p.color, marginRight: 6 }} />
          {p.name}: <span style={{ fontFamily: 'JetBrains Mono, monospace' }}>${p.value.toLocaleString()}</span>
        </p>
      ))}
    </div>
  )
}

function PieTooltip({ active, payload }: { active?: boolean; payload?: Array<{ name: string; value: number; payload: { color: string } }> }) {
  if (!active || !payload?.length) return null
  const p = payload[0]
  return (
    <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: '8px 12px', boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }}>
      <p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>{p.name}: <span style={{ fontFamily: 'JetBrains Mono, monospace' }}>${p.value}</span></p>
    </div>
  )
}

// ─── Transaction table ────────────────────────────────────────────────────────
function TxTable({ rows }: { rows: Transaction[] }) {
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ borderBottom: `1.5px solid ${C.border}` }}>
            {['Transaction', 'Category', 'Date', 'Amount', 'Type'].map(h => (
              <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: C.textDim, letterSpacing: '0.04em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((tx, i) => (
            <tr key={tx.id} style={{ borderBottom: i < rows.length - 1 ? `1px solid ${C.border}` : 'none', transition: 'background 0.1s' }}
              onMouseEnter={e => (e.currentTarget.style.background = C.bg)}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
            >
              <td style={{ padding: '13px 16px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: `${tx.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>{tx.icon}</div>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>{tx.name}</span>
                </div>
              </td>
              <td style={{ padding: '13px 16px' }}>
                <Tag color={C.slate} bg={C.surfaceHigh}>{tx.category}</Tag>
              </td>
              <td style={{ padding: '13px 16px', fontSize: 13, color: C.textSub, fontWeight: 500 }}>{tx.date}</td>
              <td style={{ padding: '13px 16px', fontSize: 14, fontWeight: 700, fontFamily: 'JetBrains Mono, monospace', color: tx.type === 'income' ? C.income : C.text }}>
                {tx.type === 'income' ? '+' : '−'}${Math.abs(tx.amount).toFixed(2)}
              </td>
              <td style={{ padding: '13px 16px' }}>
                <Tag color={tx.type === 'income' ? C.income : C.red} bg={tx.type === 'income' ? C.incomeDim : C.redDim}>
                  {tx.type === 'income' ? 'Income' : 'Expense'}
                </Tag>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ─── Page: Overview ───────────────────────────────────────────────────────────
function OverviewPage() {
  return (
    <div>
      <PageHeader title="Overview" sub="July 2026 · All accounts"
        action={<DBtn variant="secondary"><SI.Download /> Export</DBtn>}
      />

      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard label="Total Balance" value="$24,390" trend="+8.2%" trendUp />
        <StatCard label="Monthly Income" value="$6,050" trend="+12.4%" trendUp />
        <StatCard label="Monthly Expenses" value="$3,284" trend="−3.1%" trendUp />
        <StatCard label="Savings Rate" value="45.7%" trend="+2.1pp" trendUp />
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 16 }}>
        <ChartCard title="Portfolio Balance" sub="8-month trend" action={<Tag color={C.green} bg={C.greenDim}>+34.3%</Tag>}>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={balanceHistory} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="balGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.green} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={C.green} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: C.textDim, fontFamily: 'Manrope' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim, fontFamily: 'Manrope' }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="balance" name="Balance" stroke={C.green} strokeWidth={2.5} fill="url(#balGrad)" dot={false} activeDot={{ r: 5, fill: C.green }} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="By Category" sub="This month">
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={categoryChartData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                {categoryChartData.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip content={<PieTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
            {categoryChartData.slice(0, 4).map(c => (
              <div key={c.name} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 8, height: 8, borderRadius: 2, background: c.color, flexShrink: 0 }} />
                <span style={{ fontSize: 12, color: C.textSub, flex: 1, fontWeight: 500 }}>{c.name}</span>
                <span style={{ fontSize: 12, fontFamily: 'JetBrains Mono, monospace', fontWeight: 500 }}>${c.value}</span>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      {/* Income vs Expenses */}
      <div style={{ marginBottom: 16 }}>
        <ChartCard title="Income vs Expenses" sub="Last 8 months">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 0, left: 0 }} barGap={4}>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: C.textDim, fontFamily: 'Manrope' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim, fontFamily: 'Manrope' }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12, fontFamily: 'Manrope', fontWeight: 600, paddingTop: 12 }} />
              <Bar dataKey="income" name="Income" fill={C.green} radius={[5, 5, 0, 0]} />
              <Bar dataKey="expenses" name="Expenses" fill={C.blue} radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Recent transactions */}
      <ChartCard title="Recent Transactions" sub="All accounts"
        action={<DBtn variant="ghost">View all</DBtn>}
      >
        <TxTable rows={transactions} />
      </ChartCard>
    </div>
  )
}

// ─── Page: Expenses ───────────────────────────────────────────────────────────
function ExpensesPage() {
  return (
    <div>
      <PageHeader title="Expenses" sub="Spending analysis · July 2026"
        action={<DBtn variant="secondary"><SI.Download /> Export CSV</DBtn>}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard label="This Month" value="$3,284" trend="−3.1%" trendUp />
        <StatCard label="Last Month" value="$3,392" sub="Jun 2026" />
        <StatCard label="Avg Monthly" value="$3,340" sub="Last 6 months" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: 16, marginBottom: 16 }}>
        <ChartCard title="Monthly Expenses" sub="Jan–Aug 2026">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="expenses" name="Expenses" fill={C.blue} radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Top Categories">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 4 }}>
            {topCategories.map(c => (
              <div key={c.name}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 16 }}>{c.icon}</span>
                    <span style={{ fontSize: 13, fontWeight: 600 }}>{c.name}</span>
                  </div>
                  <span style={{ fontSize: 13, fontWeight: 700, fontFamily: 'JetBrains Mono, monospace' }}>${c.amount}</span>
                </div>
                <div style={{ height: 5, background: C.surfaceHigh, borderRadius: 99 }}>
                  <div style={{ height: '100%', width: `${c.pct}%`, background: c.color, borderRadius: 99 }} />
                </div>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      <ChartCard title="All Expense Transactions">
        <TxTable rows={transactions.filter(t => t.type === 'expense')} />
      </ChartCard>
    </div>
  )
}

// ─── Page: Income ─────────────────────────────────────────────────────────────
function IncomePage() {
  return (
    <div>
      <PageHeader title="Income" sub="Revenue analysis · July 2026" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard label="This Month" value="$6,050" trend="+12.4%" trendUp />
        <StatCard label="Freelance" value="$1,200" sub="19.8% of total" />
        <StatCard label="YTD Income" value="$48,300" trend="+9.2%" trendUp />
      </div>

      <div style={{ marginBottom: 16 }}>
        <ChartCard title="Income Trend" sub="Monthly income over time" action={<Tag color={C.green} bg={C.greenDim}>↑ Growing</Tag>}>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="incGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.green} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={C.green} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="income" name="Income" stroke={C.green} strokeWidth={2.5} fill="url(#incGrad)" dot={false} activeDot={{ r: 5, fill: C.green }} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        <ChartCard title="Income Sources">
          {[
            { name: 'Salary', amount: 4850, pct: 80, color: C.green },
            { name: 'Freelance', amount: 1200, pct: 20, color: C.blue },
          ].map(s => (
            <div key={s.name} style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>{s.name}</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: C.green, fontFamily: 'JetBrains Mono, monospace' }}>${s.amount.toLocaleString()}</span>
              </div>
              <div style={{ height: 8, background: C.surfaceHigh, borderRadius: 99 }}>
                <div style={{ height: '100%', width: `${s.pct}%`, background: s.color, borderRadius: 99 }} />
              </div>
              <p style={{ margin: '5px 0 0', fontSize: 11, color: C.textDim, fontWeight: 500 }}>{s.pct}% of total income</p>
            </div>
          ))}
        </ChartCard>

        <ChartCard title="Income vs Savings">
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Line type="monotone" dataKey="income" name="Income" stroke={C.green} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="savings" name="Savings" stroke={C.blue} strokeWidth={2} dot={false} strokeDasharray="5 3" />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <ChartCard title="Income Transactions">
        <TxTable rows={transactions.filter(t => t.type === 'income')} />
      </ChartCard>
    </div>
  )
}

// ─── Page: Budgets ────────────────────────────────────────────────────────────
function BudgetsPage() {
  return (
    <div>
      <PageHeader title="Budgets" sub="Monthly budget tracking"
        action={<DBtn><SI.Overview /> New Budget</DBtn>}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard label="Total Budgeted" value="$1,850" sub="Monthly limit" />
        <StatCard label="Total Spent" value="$1,350" trend="73% used" trendUp />
        <StatCard label="Remaining" value="$500" trend="27% left" trendUp />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16, marginBottom: 16 }}>
        {budgets.map(b => {
          const pct = (b.spent / b.total) * 100
          const over = pct >= 90
          return (
            <Card key={b.id} style={{ padding: '20px 22px', border: `1px solid ${over ? 'rgba(220,38,38,0.3)' : C.border}` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
                <div style={{ width: 44, height: 44, borderRadius: 14, background: `${b.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>{b.icon}</div>
                <div style={{ flex: 1 }}>
                  <p style={{ margin: '0 0 2px', fontSize: 15, fontWeight: 700 }}>{b.category}</p>
                  <p style={{ margin: 0, fontSize: 12, color: C.textDim, fontWeight: 500 }}>Monthly budget</p>
                </div>
                {over ? <Tag color={C.red} bg={C.redDim}>⚠ Over budget</Tag> : <Tag color={C.green} bg={C.greenDim}>{Math.round(100 - pct)}% left</Tag>}
              </div>
              <div style={{ height: 8, background: C.surfaceHigh, borderRadius: 99, marginBottom: 10, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: `${Math.min(pct, 100)}%`, background: over ? C.red : b.color, borderRadius: 99, transition: 'width 0.6s ease' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 13, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>${b.spent} <span style={{ color: C.textDim, fontWeight: 500 }}>spent</span></span>
                <span style={{ fontSize: 13, color: C.textDim, fontWeight: 500, fontVariantNumeric: 'tabular-nums' }}>of ${b.total}</span>
              </div>
            </Card>
          )
        })}
      </div>

      <ChartCard title="Budget Utilization" sub="All categories">
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={budgets.map(b => ({ name: b.category.split(' ')[0], spent: b.spent, total: b.total }))} layout="vertical" margin={{ top: 0, right: 20, bottom: 0, left: 20 }}>
            <CartesianGrid strokeDasharray="2 6" stroke={C.border} horizontal={false} />
            <XAxis type="number" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`} />
            <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} width={70} />
            <Tooltip content={<ChartTooltip />} />
            <Bar dataKey="spent" name="Spent" fill={C.blue} radius={[0, 5, 5, 0]} />
            <Bar dataKey="total" name="Budget" fill={C.surfaceHigh} radius={[0, 5, 5, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}

// ─── Page: Categories ────────────────────────────────────────────────────────
function CategoriesPage() {
  return (
    <div>
      <PageHeader title="Categories" sub="Spending by category · July 2026" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        <ChartCard title="Category Distribution" sub="Donut chart">
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={categoryChartData} cx="50%" cy="50%" innerRadius={65} outerRadius={95} paddingAngle={3} dataKey="value">
                  {categoryChartData.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip content={<PieTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px 20px', width: '100%', marginTop: 8 }}>
              {categoryChartData.map(c => (
                <div key={c.name} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: c.color, flexShrink: 0 }} />
                  <span style={{ fontSize: 12, color: C.textSub, fontWeight: 500, flex: 1 }}>{c.name}</span>
                  <span style={{ fontSize: 12, fontFamily: 'JetBrains Mono, monospace', fontWeight: 600 }}>${c.value}</span>
                </div>
              ))}
            </div>
          </div>
        </ChartCard>

        <ChartCard title="Category Breakdown" sub="Ranked by spending">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {categoryChartData.sort((a, b) => b.value - a.value).map((c, i) => {
              const total = categoryChartData.reduce((s, x) => s + x.value, 0)
              return (
                <div key={c.name}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 11, fontWeight: 700, color: C.textDim, width: 16 }}>#{i + 1}</span>
                      <span style={{ fontSize: 13, fontWeight: 600 }}>{c.name}</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <Tag color={c.color} bg={`${c.color}15`}>{Math.round((c.value / total) * 100)}%</Tag>
                      <span style={{ fontSize: 13, fontWeight: 700, fontFamily: 'JetBrains Mono, monospace' }}>${c.value}</span>
                    </div>
                  </div>
                  <div style={{ height: 4, background: C.surfaceHigh, borderRadius: 99 }}>
                    <div style={{ height: '100%', width: `${(c.value / categoryChartData[0].value) * 100}%`, background: c.color, borderRadius: 99 }} />
                  </div>
                </div>
              )
            })}
          </div>
        </ChartCard>
      </div>
    </div>
  )
}

// ─── Page: Reports ────────────────────────────────────────────────────────────
function ReportsPage() {
  const [period, setPeriod] = useState<'3M' | '6M' | '1Y'>('6M')
  return (
    <div>
      <PageHeader title="Reports" sub="Financial reports & summaries"
        action={
          <div style={{ display: 'flex', gap: 8 }}>
            {(['3M', '6M', '1Y'] as const).map(p => (
              <button key={p} onClick={() => setPeriod(p)} style={{
                padding: '7px 14px', borderRadius: 10, border: `1.5px solid ${period === p ? C.green : C.border}`,
                background: period === p ? C.greenDim : C.surface, color: period === p ? C.green : C.textSub,
                fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'Manrope, sans-serif',
              }}>{p}</button>
            ))}
          </div>
        }
      />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard label="Total Income" value="$48,300" trend="+9.2%" trendUp />
        <StatCard label="Total Expenses" value="$26,272" trend="−2.1%" trendUp />
        <StatCard label="Net Savings" value="$22,028" trend="+22.4%" trendUp />
        <StatCard label="Avg Monthly Save" value="$2,754" sub="Per month" />
      </div>

      <div style={{ marginBottom: 16 }}>
        <ChartCard title="Net Savings Trend" sub="Income minus expenses">
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="savGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.green} stopOpacity={0.12} />
                  <stop offset="95%" stopColor={C.green} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="savings" name="Savings" stroke={C.green} strokeWidth={2.5} fill="url(#savGrad)" dot={false} activeDot={{ r: 5 }} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <ChartCard title="Weekly Spending Pattern">
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={weeklyData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`} />
              <Tooltip content={<ChartTooltip />} />
              <Bar dataKey="amount" name="Spending" fill={C.blue} radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Monthly Comparison">
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Line type="monotone" dataKey="income" name="Income" stroke={C.green} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="expenses" name="Expenses" stroke={C.red} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="savings" name="Savings" stroke={C.blue} strokeWidth={2} dot={false} strokeDasharray="4 3" />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}

// ─── Page: Analytics ──────────────────────────────────────────────────────────
function AnalyticsPage() {
  return (
    <div>
      <PageHeader title="Analytics" sub="Advanced financial insights" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard label="Burn Rate" value="$106/day" sub="Daily average" />
        <StatCard label="Best Month" value="Aug '26" trend="$3,200" trendUp />
        <StatCard label="Worst Month" value="Apr '26" trend="$3,800" />
        <StatCard label="Forecast Aug" value="$3,200" trend="−2.5%" trendUp />
      </div>

      <div style={{ marginBottom: 16 }}>
        <ChartCard title="Cumulative Savings Growth" sub="Balance building over time">
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={balanceHistory} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="cumGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.blue} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={C.blue} stopOpacity={0} />
                </linearGradient>
                <linearGradient id="cumGrad2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.green} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={C.green} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="balance" name="Balance" stroke={C.blue} strokeWidth={2.5} fill="url(#cumGrad)" dot={false} activeDot={{ r: 5 }} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 }}>
        <ChartCard title="Income vs Expenses vs Savings" sub="Full comparison">
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="2 6" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip content={<ChartTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12, fontFamily: 'Manrope', fontWeight: 600, paddingTop: 12 }} />
              <Line type="monotone" dataKey="income" name="Income" stroke={C.green} strokeWidth={2.5} dot={false} activeDot={{ r: 4 }} />
              <Line type="monotone" dataKey="expenses" name="Expenses" stroke={C.red} strokeWidth={2.5} dot={false} activeDot={{ r: 4 }} />
              <Line type="monotone" dataKey="savings" name="Savings" stroke={C.blue} strokeWidth={2.5} dot={false} activeDot={{ r: 4 }} strokeDasharray="5 3" />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Spending Insights">
          {[
            { label: 'Weekday avg.', value: '$68', color: C.blue },
            { label: 'Weekend avg.', value: '$138', color: C.amber },
            { label: 'Peak day', value: 'Saturday', color: C.red },
            { label: 'Quiet day', value: 'Wednesday', color: C.green },
            { label: 'Fixed costs', value: '38%', color: C.violet },
            { label: 'Variable', value: '62%', color: C.teal },
          ].map(i => (
            <div key={i.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: `1px solid ${C.border}` }}>
              <span style={{ fontSize: 13, color: C.textSub, fontWeight: 500 }}>{i.label}</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: i.color }}>{i.value}</span>
            </div>
          ))}
        </ChartCard>
      </div>
    </div>
  )
}

// ─── Page: Users ──────────────────────────────────────────────────────────────
function UsersPage() {
  const users = [
    { name: 'Maya Chen', email: 'maya@example.com', role: 'Owner', joined: 'Jan 2024', txns: 342, balance: '$24,390', avatar: '👤', status: 'active' },
    { name: 'James Rivera', email: 'james@example.com', role: 'Member', joined: 'Mar 2024', txns: 128, balance: '$8,240', avatar: '👤', status: 'active' },
    { name: 'Sofia Park', email: 'sofia@example.com', role: 'Member', joined: 'Jun 2024', txns: 74, balance: '$3,180', avatar: '👤', status: 'inactive' },
  ]
  return (
    <div>
      <PageHeader title="User Management" sub="Account holders & members"
        action={<DBtn>+ Invite Member</DBtn>}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard label="Total Users" value="3" sub="Active accounts" />
        <StatCard label="Active" value="2" trend="67% active" trendUp />
        <StatCard label="Total Transactions" value="544" sub="All users combined" />
      </div>

      <ChartCard title="Account Members">
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: `1.5px solid ${C.border}` }}>
              {['User', 'Role', 'Joined', 'Transactions', 'Balance', 'Status', ''].map(h => (
                <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: C.textDim, letterSpacing: '0.04em', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={u.email} style={{ borderBottom: i < users.length - 1 ? `1px solid ${C.border}` : 'none' }}>
                <td style={{ padding: '14px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 36, height: 36, borderRadius: '50%', background: C.greenDim, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>{u.avatar}</div>
                    <div>
                      <p style={{ margin: '0 0 2px', fontSize: 14, fontWeight: 700 }}>{u.name}</p>
                      <p style={{ margin: 0, fontSize: 12, color: C.textDim }}>{u.email}</p>
                    </div>
                  </div>
                </td>
                <td style={{ padding: '14px 16px' }}><Tag color={u.role === 'Owner' ? C.green : C.blue} bg={u.role === 'Owner' ? C.greenDim : C.blueDim}>{u.role}</Tag></td>
                <td style={{ padding: '14px 16px', fontSize: 13, color: C.textSub }}>{u.joined}</td>
                <td style={{ padding: '14px 16px', fontSize: 13, fontWeight: 600, fontFamily: 'JetBrains Mono, monospace' }}>{u.txns}</td>
                <td style={{ padding: '14px 16px', fontSize: 13, fontWeight: 700, color: C.green, fontFamily: 'JetBrains Mono, monospace' }}>{u.balance}</td>
                <td style={{ padding: '14px 16px' }}><Tag color={u.status === 'active' ? C.green : C.textDim} bg={u.status === 'active' ? C.greenDim : C.surfaceHigh}>{u.status}</Tag></td>
                <td style={{ padding: '14px 16px' }}><DBtn variant="ghost">Manage</DBtn></td>
              </tr>
            ))}
          </tbody>
        </table>
      </ChartCard>
    </div>
  )
}

// ─── Page: Settings ──────────────────────────────────────────────────────────
function SettingsPage() {
  const [notif, setNotif] = useState(true)
  const [sync, setSync] = useState(true)
  const [twofa, setTwofa] = useState(false)

  function Toggle({ on, fn }: { on: boolean; fn: () => void }) {
    return (
      <div onClick={fn} style={{ width: 42, height: 24, borderRadius: 99, cursor: 'pointer', background: on ? C.green : C.border, transition: 'background 0.2s', position: 'relative', flexShrink: 0 }}>
        <div style={{ position: 'absolute', top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: '50%', background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.2)', transition: 'left 0.2s' }} />
      </div>
    )
  }

  return (
    <div>
      <PageHeader title="Settings" sub="Account and application preferences" />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 24 }}>
        {/* Profile */}
        <div>
          <Card style={{ padding: '24px', textAlign: 'center', marginBottom: 16 }}>
            <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'linear-gradient(135deg, var(--c-primary), var(--c-primary-dark))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30, margin: '0 auto 14px', boxShadow: `0 0 0 4px ${C.greenDim}` }}>👤</div>
            <h3 style={{ margin: '0 0 4px', fontSize: 18, fontWeight: 800 }}>Maya Chen</h3>
            <p style={{ margin: '0 0 16px', fontSize: 13, color: C.textSub }}>maya@example.com</p>
            <Tag color={C.green} bg={C.greenDim}>✦ Premium</Tag>
            <div style={{ marginTop: 16 }}>
              <DBtn variant="secondary">Edit Profile</DBtn>
            </div>
          </Card>

          <Card style={{ padding: '16px 20px' }}>
            <p style={{ margin: '0 0 12px', fontSize: 12, color: C.textDim, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Account Stats</p>
            {[
              { label: 'Member since', value: 'Jan 2024' },
              { label: 'Transactions', value: '342' },
              { label: 'Budgets active', value: '6' },
              { label: 'Data synced', value: '2 min ago' },
            ].map((s, i, arr) => (
              <div key={s.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: i < arr.length - 1 ? `1px solid ${C.border}` : 'none' }}>
                <span style={{ fontSize: 13, color: C.textSub, fontWeight: 500 }}>{s.label}</span>
                <span style={{ fontSize: 13, fontWeight: 700 }}>{s.value}</span>
              </div>
            ))}
          </Card>
        </div>

        {/* Settings panels */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {[
            {
              title: 'Notifications',
              items: [
                { label: 'Push notifications', sub: 'Budget alerts and summaries', toggle: true, on: notif, fn: () => setNotif(!notif) },
                { label: 'Cloud sync', sub: 'Auto-sync transactions', toggle: true, on: sync, fn: () => setSync(!sync) },
                { label: 'Two-factor auth', sub: 'Extra security layer', toggle: true, on: twofa, fn: () => setTwofa(!twofa) },
              ],
            },
            {
              title: 'Preferences',
              items: [
                { label: 'Currency', sub: 'USD — US Dollar', toggle: false, on: false, fn: () => {} },
                { label: 'Language', sub: 'English (US)', toggle: false, on: false, fn: () => {} },
                { label: 'Date format', sub: 'MM/DD/YYYY', toggle: false, on: false, fn: () => {} },
              ],
            },
            {
              title: 'Data & Privacy',
              items: [
                { label: 'Export all data', sub: 'Download as CSV or PDF', toggle: false, on: false, fn: () => {} },
                { label: 'Privacy settings', sub: 'Manage data sharing', toggle: false, on: false, fn: () => {} },
                { label: 'Delete account', sub: 'Permanently remove account', toggle: false, on: false, fn: () => {} },
              ],
            },
          ].map(sec => (
            <Card key={sec.title} style={{ overflow: 'hidden' }}>
              <p style={{ margin: 0, padding: '16px 20px', fontSize: 14, fontWeight: 700, borderBottom: `1px solid ${C.border}`, background: C.bg }}>{sec.title}</p>
              {sec.items.map((item, i, arr) => (
                <div key={item.label} style={{ display: 'flex', alignItems: 'center', padding: '14px 20px', borderBottom: i < arr.length - 1 ? `1px solid ${C.border}` : 'none', gap: 14 }}>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: '0 0 2px', fontSize: 14, fontWeight: 600 }}>{item.label}</p>
                    <p style={{ margin: 0, fontSize: 12, color: C.textDim, fontWeight: 500 }}>{item.sub}</p>
                  </div>
                  {item.toggle
                    ? <Toggle on={item.on} fn={item.fn} />
                    : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.textDim} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18l6-6-6-6"/></svg>}
                </div>
              ))}
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const navItems: { id: Page; label: string; Icon: () => React.ReactElement; group?: string }[] = [
  { id: 'overview', label: 'Overview', Icon: SI.Overview },
  { id: 'expenses', label: 'Expenses', Icon: SI.Expenses, group: 'Transactions' },
  { id: 'income', label: 'Income', Icon: SI.Income, group: 'Transactions' },
  { id: 'budgets', label: 'Budgets', Icon: SI.Budgets, group: 'Planning' },
  { id: 'categories', label: 'Categories', Icon: SI.Categories, group: 'Planning' },
  { id: 'reports', label: 'Reports', Icon: SI.Reports, group: 'Analysis' },
  { id: 'analytics', label: 'Analytics', Icon: SI.Analytics, group: 'Analysis' },
  { id: 'users', label: 'Users', Icon: SI.Users, group: 'Management' },
  { id: 'settings', label: 'Settings', Icon: SI.Settings, group: 'Management' },
]

function Sidebar({ page, setPage }: { page: Page; setPage: (p: Page) => void }) {
  let lastGroup = ''
  return (
    <div style={{
      width: 240, background: C.sidebar, display: 'flex', flexDirection: 'column',
      position: 'fixed', left: 0, top: 58, bottom: 0, overflowY: 'auto',
    }}>
      {/* Logo */}
      <div style={{ padding: '24px 20px 20px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ width: 36, height: 36, borderRadius: 11, background: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🌿</div>
        <span style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>Finflow</span>
      </div>

      {/* Nav items */}
      <div style={{ flex: 1, padding: '16px 12px' }}>
        {navItems.map(item => {
          const showGroup = item.group && item.group !== lastGroup
          if (item.group) lastGroup = item.group
          const active = page === item.id
          return (
            <div key={item.id}>
              {showGroup && (
                <p style={{ margin: '16px 0 6px 8px', fontSize: 10, fontWeight: 700, color: 'rgba(255,255,255,0.3)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{item.group}</p>
              )}
              <button onClick={() => setPage(item.id)} style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 12px', borderRadius: 10, border: 'none', cursor: 'pointer',
                background: active ? 'rgba(255,255,255,0.1)' : 'transparent',
                color: active ? '#fff' : 'rgba(255,255,255,0.55)',
                fontSize: 13, fontWeight: active ? 700 : 500,
                fontFamily: 'Manrope, sans-serif',
                transition: 'all 0.15s',
                marginBottom: 2,
              }}
                onMouseEnter={e => !active && (e.currentTarget.style.background = 'rgba(255,255,255,0.06)')}
                onMouseLeave={e => !active && (e.currentTarget.style.background = 'transparent')}
              >
                {active && <div style={{ position: 'absolute', left: 0, width: 3, height: 24, borderRadius: '0 99px 99px 0', background: C.green }} />}
                <item.Icon />
                {item.label}
              </button>
            </div>
          )
        })}
      </div>

      {/* User footer */}
      <div style={{ padding: '16px 20px', borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'linear-gradient(135deg, var(--c-primary), var(--c-primary-dark))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>👤</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ margin: '0 0 1px', fontSize: 13, fontWeight: 700, color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>Maya Chen</p>
          <p style={{ margin: 0, fontSize: 11, color: 'rgba(255,255,255,0.4)', fontWeight: 500 }}>Premium</p>
        </div>
      </div>
    </div>
  )
}

// ─── Top bar ──────────────────────────────────────────────────────────────────
function TopBar({ page }: { page: Page }) {
  const label = navItems.find(n => n.id === page)?.label ?? 'Dashboard'
  return (
    <div style={{
      position: 'fixed', top: 58, left: 240, right: 0, height: 56,
      background: C.surface, borderBottom: `1px solid ${C.border}`,
      display: 'flex', alignItems: 'center', padding: '0 24px',
      gap: 16, zIndex: 100, boxShadow: '0 1px 0 rgba(0,0,0,0.04)',
    }}>
      <p style={{ margin: 0, fontSize: 14, fontWeight: 500, color: C.textDim }}>
        <span style={{ color: C.green }}>Finflow</span> / {label}
      </p>
      <div style={{ flex: 1 }} />
      {/* Search */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: C.bg, border: `1px solid ${C.border}`, borderRadius: 10, padding: '7px 12px', width: 200 }}>
        <SI.Search />
        <input placeholder="Search..." style={{ border: 'none', background: 'transparent', outline: 'none', fontSize: 13, color: C.text, fontFamily: 'Manrope, sans-serif', width: '100%' }} />
      </div>
      {/* Bell */}
      <button style={{ width: 36, height: 36, borderRadius: 10, background: C.bg, border: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', position: 'relative', color: C.textSub }}>
        <SI.Bell />
        <span style={{ position: 'absolute', top: 6, right: 6, width: 6, height: 6, borderRadius: '50%', background: C.red, border: `1.5px solid ${C.surface}` }} />
      </button>
      {/* Avatar */}
      <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'linear-gradient(135deg, var(--c-primary), var(--c-primary-dark))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, cursor: 'pointer' }}>👤</div>
    </div>
  )
}

// ─── Dashboard shell ──────────────────────────────────────────────────────────
export default function Dashboard() {
  const [page, setPage] = useState<Page>('overview')

  const PageComp: Record<Page, React.ComponentType> = {
    overview: OverviewPage,
    expenses: ExpensesPage,
    income: IncomePage,
    budgets: BudgetsPage,
    categories: CategoriesPage,
    reports: ReportsPage,
    analytics: AnalyticsPage,
    users: UsersPage,
    settings: SettingsPage,
  }
  const Comp = PageComp[page]

  return (
    <div style={{ display: 'flex', minHeight: 'calc(100vh - 58px)', background: C.bg }}>
      <Sidebar page={page} setPage={setPage} />
      <div style={{ marginLeft: 240, flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar page={page} />
        <div style={{ marginTop: 56, padding: '28px 28px 48px', flex: 1 }}>
          <Comp />
        </div>
      </div>
    </div>
  )
}
