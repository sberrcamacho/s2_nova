/* Shared color tokens — all values are CSS custom properties so light/dark
   switches by toggling data-theme="dark" on <html>. No re-render needed. */
export const C = {
  bg:           'var(--c-bg)',
  surface:      'var(--c-surface)',
  surfaceHigh:  'var(--c-surface-high)',
  border:       'var(--c-border)',
  borderStrong: 'var(--c-border-strong)',
  text:         'var(--c-text)',
  textSub:      'var(--c-text-sub)',
  textDim:      'var(--c-text-dim)',

  /* Primary accent — green in light, blue-purple in dark */
  green:     'var(--c-primary)',
  greenDim:  'var(--c-primary-dim)',
  greenLight: 'var(--c-primary-dim)',

  /* Income / positive financial meaning — stays green in both modes */
  income:    'var(--c-income)',
  incomeDim: 'var(--c-income-dim)',

  blue:      'var(--c-blue)',
  blueDim:   'var(--c-blue-dim)',
  blueLight: 'var(--c-blue-dim)',

  red:       'var(--c-red)',
  redDim:    'var(--c-red-dim)',
  amber:     'var(--c-amber)',
  amberDim:  'var(--c-amber-dim)',
  violet:    'var(--c-violet)',
  violetDim: 'var(--c-violet-dim)',
  teal:      'var(--c-teal)',
  tealDim:   'var(--c-teal-dim)',
  slate:     'var(--c-slate)',

  /* Dashboard */
  sidebar:      'var(--c-sidebar)',
  sidebarText:  'rgba(255,255,255,0.55)',
  sidebarActive: '#ffffff',
}
