export interface Transaction {
  id: string
  name: string
  category: string
  icon: string
  amount: number
  date: string
  type: 'expense' | 'income'
  note?: string
  color: string
}

export interface Budget {
  id: string
  category: string
  icon: string
  color: string
  spent: number
  total: number
}

export interface Notification {
  id: string
  title: string
  message: string
  time: string
  read: boolean
  type: 'alert' | 'info' | 'success'
}

export const transactions: Transaction[] = [
  { id: '1', name: 'Salary — Acme Corp', category: 'Income', icon: '💼', amount: 4850, date: 'Aug 1', type: 'income', note: 'Monthly salary deposit', color: '#16a34a' },
  { id: '2', name: 'Spotify Premium', category: 'Entertainment', icon: '🎵', amount: -9.99, date: 'Aug 1', type: 'expense', color: '#d97706' },
  { id: '3', name: 'Whole Foods Market', category: 'Groceries', icon: '🛒', amount: -84.32, date: 'Jul 31', type: 'expense', note: 'Weekly groceries', color: '#d97706' },
  { id: '4', name: 'Netflix', category: 'Entertainment', icon: '📺', amount: -15.49, date: 'Jul 30', type: 'expense', color: '#d97706' },
  { id: '5', name: 'Uber Eats', category: 'Dining', icon: '🍔', amount: -27.80, date: 'Jul 29', type: 'expense', color: '#7c3aed' },
  { id: '6', name: 'PureGym Membership', category: 'Health', icon: '🏋️', amount: -45.00, date: 'Jul 28', type: 'expense', color: '#2563eb' },
  { id: '7', name: 'Amazon Prime', category: 'Shopping', icon: '📦', amount: -14.99, date: 'Jul 27', type: 'expense', color: '#0d9488' },
  { id: '8', name: 'Freelance — Studio M', category: 'Income', icon: '✏️', amount: 1200, date: 'Jul 26', type: 'income', color: '#16a34a' },
  { id: '9', name: 'Electricity Bill', category: 'Utilities', icon: '⚡', amount: -62.50, date: 'Jul 25', type: 'expense', color: '#dc2626' },
  { id: '10', name: 'Zara — Jacket', category: 'Shopping', icon: '👕', amount: -89.00, date: 'Jul 24', type: 'expense', color: '#0d9488' },
  { id: '11', name: 'Morning Coffee', category: 'Dining', icon: '☕', amount: -4.80, date: 'Jul 23', type: 'expense', color: '#7c3aed' },
  { id: '12', name: 'Monthly Bus Pass', category: 'Transport', icon: '🚌', amount: -68.00, date: 'Jul 22', type: 'expense', color: '#64748b' },
]

export const budgets: Budget[] = [
  { id: '1', category: 'Groceries', icon: '🛒', color: '#d97706', spent: 284, total: 400 },
  { id: '2', category: 'Dining Out', icon: '🍽️', color: '#7c3aed', spent: 178, total: 200 },
  { id: '3', category: 'Entertainment', icon: '🎬', color: '#f59e0b', spent: 63, total: 80 },
  { id: '4', category: 'Health & Fitness', icon: '💪', color: '#2563eb', spent: 45, total: 120 },
  { id: '5', category: 'Shopping', icon: '🛍️', color: '#0d9488', spent: 237, total: 300 },
  { id: '6', category: 'Transport', icon: '🚗', color: '#64748b', spent: 68, total: 150 },
]

export const notifications: Notification[] = [
  { id: '1', title: 'Budget Alert', message: 'Dining budget is 89% used this month', time: '2 min ago', read: false, type: 'alert' },
  { id: '2', title: 'Income Received', message: '+$4,850 salary credited to your account', time: '1 hour ago', read: false, type: 'success' },
  { id: '3', title: 'Barcode Scanned', message: 'Whole Foods receipt added — $84.32', time: '3 hours ago', read: true, type: 'info' },
  { id: '4', title: 'Monthly Report Ready', message: 'Your July 2026 summary is available', time: 'Yesterday', read: true, type: 'info' },
  { id: '5', title: 'Spending Alert', message: 'Entertainment is higher than usual', time: '2 days ago', read: true, type: 'alert' },
  { id: '6', title: 'Goal Reached', message: 'You saved 45% of income this month 🎉', time: '3 days ago', read: true, type: 'success' },
]

export const monthlyData = [
  { month: 'Jan', income: 5800, expenses: 3200, savings: 2600 },
  { month: 'Feb', income: 6100, expenses: 3600, savings: 2500 },
  { month: 'Mar', income: 5900, expenses: 3100, savings: 2800 },
  { month: 'Apr', income: 6300, expenses: 3800, savings: 2500 },
  { month: 'May', income: 6000, expenses: 3300, savings: 2700 },
  { month: 'Jun', income: 6200, expenses: 3500, savings: 2700 },
  { month: 'Jul', income: 6050, expenses: 3284, savings: 2766 },
  { month: 'Aug', income: 6400, expenses: 3200, savings: 3200 },
]

export const weeklyData = [
  { day: 'Mon', amount: 42 },
  { day: 'Tue', amount: 78 },
  { day: 'Wed', amount: 31 },
  { day: 'Thu', amount: 95 },
  { day: 'Fri', amount: 143 },
  { day: 'Sat', amount: 210 },
  { day: 'Sun', amount: 67 },
]

export const balanceHistory = [
  { month: 'Jan', balance: 18200 },
  { month: 'Feb', balance: 20700 },
  { month: 'Mar', balance: 23500 },
  { month: 'Apr', balance: 21000 },
  { month: 'May', balance: 23700 },
  { month: 'Jun', balance: 26400 },
  { month: 'Jul', balance: 24390 },
  { month: 'Aug', balance: 27600 },
]

export const categoryChartData = [
  { name: 'Groceries', value: 284, color: '#d97706' },
  { name: 'Dining', value: 178, color: '#7c3aed' },
  { name: 'Shopping', value: 237, color: '#0d9488' },
  { name: 'Entertainment', value: 63, color: '#f59e0b' },
  { name: 'Health', value: 45, color: '#2563eb' },
  { name: 'Transport', value: 68, color: '#64748b' },
  { name: 'Utilities', value: 62, color: '#dc2626' },
]

export const topCategories = [
  { name: 'Groceries', icon: '🛒', color: '#d97706', amount: 284, pct: 32 },
  { name: 'Shopping', icon: '🛍️', color: '#0d9488', amount: 237, pct: 27 },
  { name: 'Dining', icon: '🍽️', color: '#7c3aed', amount: 178, pct: 20 },
  { name: 'Transport', icon: '🚌', color: '#64748b', amount: 68, pct: 8 },
  { name: 'Health', icon: '💪', color: '#2563eb', amount: 45, pct: 5 },
]
