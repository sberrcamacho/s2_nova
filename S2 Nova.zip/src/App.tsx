import { useState, useEffect } from 'react'
import MobileApp from './MobileApp'
import Dashboard from './Dashboard'

type Mode = 'mobile' | 'dashboard'

export default function App() {
  const [mode, setMode] = useState<Mode>('dashboard')
  const [dark, setDark] = useState(false)

  useEffect(() => {
    if (dark) {
      document.documentElement.setAttribute('data-theme', 'dark')
    } else {
      document.documentElement.removeAttribute('data-theme')
    }
  }, [dark])

  const pillBg = dark ? '#0e0e16' : '#ffffff'
  const pillBorder = dark ? '#1d1d2c' : '#e2e8f0'
  const activeBtn = dark ? '#6c63ff' : '#0f172a'
  const inactiveText = dark ? '#a9a9b8' : '#64748b'

  return (
    <div style={{
      minHeight: '100vh',
      background: dark
        ? '#050508'
        : mode === 'mobile'
          ? 'linear-gradient(140deg, #f0fdf4 0%, #eff6ff 55%, #f8fafc 100%)'
          : '#f1f5f9',
      transition: 'background 0.35s ease',
    }}>
      {/* Mode + theme toggle */}
      <div style={{
        position: 'fixed', top: 14, left: '50%', transform: 'translateX(-50%)',
        display: 'flex', alignItems: 'center', gap: 6,
        background: pillBg,
        border: `1px solid ${pillBorder}`,
        borderRadius: 99, padding: 4,
        boxShadow: dark ? '0 4px 24px rgba(0,0,0,0.5)' : '0 4px 24px rgba(0,0,0,0.1)',
        zIndex: 9999,
        transition: 'all 0.3s ease',
      }}>
        {(['mobile', 'dashboard'] as Mode[]).map(m => (
          <button key={m} onClick={() => setMode(m)} style={{
            padding: '7px 18px', borderRadius: 99, border: 'none', cursor: 'pointer',
            background: mode === m ? activeBtn : 'transparent',
            color: mode === m ? '#fff' : inactiveText,
            fontSize: 13, fontWeight: 700,
            fontFamily: 'Manrope, sans-serif',
            transition: 'all 0.2s ease',
            display: 'flex', alignItems: 'center', gap: 6,
            whiteSpace: 'nowrap',
          }}>
            {m === 'mobile' ? '📱 Mobile App' : '🖥️ Dashboard'}
          </button>
        ))}

        <div style={{
          width: 1, height: 24, background: pillBorder, margin: '0 2px', flexShrink: 0,
        }} />

        {/* Dark mode toggle */}
        <button
          onClick={() => setDark(d => !d)}
          title={dark ? 'Switch to light mode' : 'Switch to dark mode'}
          style={{
            width: 36, height: 36, borderRadius: 99, border: 'none', cursor: 'pointer',
            background: dark ? 'rgba(108,99,255,0.18)' : 'rgba(0,0,0,0.06)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16, transition: 'all 0.2s ease', flexShrink: 0,
          }}
        >
          {dark ? '☀️' : '🌙'}
        </button>
      </div>

      {mode === 'mobile' ? (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          minHeight: '100vh', paddingTop: 70, paddingBottom: 40,
        }}>
          <MobileApp />
        </div>
      ) : (
        <div style={{ paddingTop: 58 }}>
          <Dashboard />
        </div>
      )}
    </div>
  )
}
