import { useState } from 'react'
import { transactions, budgets, notifications, weeklyData, monthlyData } from './data'
import type { Transaction } from './data'
import {
  AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from 'recharts'
import { C } from './theme'

// ─── Screen type ──────────────────────────────────────────────────────────────
type Screen = 'login' | 'signup' | 'home' | 'notifications' | 'scan' |
  'add-tx' | 'tx-detail' | 'categories' | 'budgets' |
  'monthly' | 'reports' | 'profile' | 'settings'

const MAIN_SCREENS: Screen[] = ['home', 'reports', 'budgets', 'profile']

// ─── Icons ────────────────────────────────────────────────────────────────────
const Ic = {
  Home: ({ c = C.textDim }: { c?: string }) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z"/><path d="M9 21V13h6v8"/>
    </svg>
  ),
  Chart: ({ c = C.textDim }: { c?: string }) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
    </svg>
  ),
  Wallet: ({ c = C.textDim }: { c?: string }) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="5" width="20" height="14" rx="3"/><path d="M16 12h.01"/>
    </svg>
  ),
  User: ({ c = C.textDim }: { c?: string }) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
    </svg>
  ),
  Plus: ({ c = '#fff' }: { c?: string }) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.5" strokeLinecap="round">
      <path d="M12 5v14M5 12h14"/>
    </svg>
  ),
  Bell: ({ c = C.text }: { c?: string }) => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>
    </svg>
  ),
  Back: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={C.text} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 12H5M12 5l-7 7 7 7"/>
    </svg>
  ),
  ChevronRight: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.textDim} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 18l6-6-6-6"/>
    </svg>
  ),
  Scan: ({ c = '#fff' }: { c?: string }) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M21 17v2a2 2 0 01-2 2h-2M7 21H5a2 2 0 01-2-2v-2M8 12h8"/>
    </svg>
  ),
  Search: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.textDim} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
    </svg>
  ),
  Edit: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
    </svg>
  ),
  Check: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>
  ),
}

// ─── Primitives ───────────────────────────────────────────────────────────────
function MInput({ label, type = 'text', placeholder, value, onChange, right }: {
  label?: string; type?: string; placeholder?: string;
  value?: string; onChange?: (v: string) => void; right?: React.ReactNode
}) {
  return (
    <div>
      {label && <p style={{ margin: '0 0 6px', fontSize: 12, fontWeight: 600, color: C.textSub }}>{label}</p>}
      <div style={{ position: 'relative' }}>
        <input type={type} placeholder={placeholder} value={value}
          onChange={e => onChange?.(e.target.value)}
          style={{
            width: '100%', padding: '13px 16px', paddingRight: right ? 44 : 16,
            border: `1.5px solid ${C.border}`, borderRadius: 12,
            fontSize: 14, fontWeight: 500, fontFamily: 'Manrope, sans-serif',
            color: C.text, background: C.surface, outline: 'none',
          }}
        />
        {right && (
          <div style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)' }}>{right}</div>
        )}
      </div>
    </div>
  )
}

function MBtn({ children, onClick, variant = 'primary', full = false }: {
  children: React.ReactNode; onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; full?: boolean
}) {
  const styles: Record<string, React.CSSProperties> = {
    primary: { background: C.green, color: '#fff', border: 'none' },
    secondary: { background: C.surface, color: C.text, border: `1.5px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.green, border: 'none' },
    danger: { background: C.redDim, color: C.red, border: `1px solid rgba(220,38,38,0.2)` },
  }
  return (
    <button onClick={onClick} style={{
      ...styles[variant],
      width: full ? '100%' : 'auto',
      padding: '13px 22px', borderRadius: 12,
      fontSize: 14, fontWeight: 700, cursor: 'pointer',
      fontFamily: 'Manrope, sans-serif',
      transition: 'opacity 0.15s',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    }}>{children}</button>
  )
}

function MHeader({ title, back, right }: { title: string; back?: () => void; right?: React.ReactNode }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '16px 20px', background: C.surface,
      borderBottom: `1px solid ${C.border}`, flexShrink: 0,
    }}>
      {back && (
        <button onClick={back} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, borderRadius: 8, display: 'flex' }}>
          <Ic.Back />
        </button>
      )}
      <h2 style={{ margin: 0, flex: 1, fontSize: 17, fontWeight: 700 }}>{title}</h2>
      {right}
    </div>
  )
}

function TxRow({ tx, onPress }: { tx: Transaction; onPress?: () => void }) {
  return (
    <div onClick={onPress} style={{
      display: 'flex', alignItems: 'center', gap: 14, padding: '12px 20px',
      cursor: onPress ? 'pointer' : 'default',
      borderBottom: `1px solid ${C.border}`,
    }}>
      <div style={{ width: 42, height: 42, borderRadius: 13, background: `${tx.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>
        {tx.icon}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: '0 0 2px', fontSize: 14, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tx.name}</p>
        <p style={{ margin: 0, fontSize: 11, color: C.textDim, fontWeight: 500 }}>{tx.category} · {tx.date}</p>
      </div>
      <span style={{
        fontSize: 14, fontWeight: 700, fontFamily: 'JetBrains Mono, monospace', flexShrink: 0,
        color: tx.type === 'income' ? C.income : C.text,
      }}>
        {tx.type === 'income' ? '+' : '−'}${Math.abs(tx.amount).toFixed(2)}
      </span>
    </div>
  )
}

function Tag({ children, color, bg }: { children: React.ReactNode; color: string; bg: string }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: bg, color, borderRadius: 99, padding: '3px 10px', fontSize: 11, fontWeight: 700 }}>
      {children}
    </span>
  )
}

function ProgressBar({ pct, color }: { pct: number; color: string }) {
  const over = pct >= 90
  return (
    <div style={{ height: 5, background: C.surfaceHigh, borderRadius: 99, overflow: 'hidden' }}>
      <div style={{ height: '100%', width: `${Math.min(pct, 100)}%`, background: over ? C.red : color, borderRadius: 99, transition: 'width 0.5s ease' }} />
    </div>
  )
}

// ─── Status Bar ───────────────────────────────────────────────────────────────
function StatusBar() {
  return (
    <div style={{ height: 34, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px 0 24px', background: C.surface, flexShrink: 0 }}>
      <span style={{ fontSize: 13, fontWeight: 700, fontFamily: 'JetBrains Mono, monospace' }}>9:41</span>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="15" height="11" viewBox="0 0 15 11" fill={C.text}>
          <rect x="0" y="7" width="2.5" height="4" rx="0.5" opacity="0.7"/>
          <rect x="3.5" y="4.5" width="2.5" height="6.5" rx="0.5" opacity="0.7"/>
          <rect x="7" y="2" width="2.5" height="9" rx="0.5" opacity="0.7"/>
          <rect x="10.5" y="0" width="2.5" height="11" rx="0.5"/>
        </svg>
        <svg width="16" height="11" viewBox="0 0 16 11" fill="none">
          <path d="M8 8.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3z" fill={C.text}/>
          <path d="M3.5 5.8C5 4.3 6.4 3.6 8 3.6s3 .7 4.5 2.2" stroke={C.text} strokeWidth="1.5" strokeLinecap="round" opacity="0.7"/>
          <path d="M1 3.2C3.2 1.1 5.5.2 8 .2s4.8 .9 7 3" stroke={C.text} strokeWidth="1.5" strokeLinecap="round" opacity="0.4"/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12" fill="none">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3.5" stroke={C.text} strokeOpacity="0.35"/>
          <rect x="2" y="2" width="17" height="8" rx="2" fill={C.green}/>
          <path d="M24 4.5v3a1.5 1.5 0 000-3z" fill={C.text} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  )
}

// ─── Bottom Nav ───────────────────────────────────────────────────────────────
function BottomNav({ screen, goTab, nav }: { screen: Screen; goTab: (s: Screen) => void; nav: (s: Screen) => void }) {
  type NavItem = { id: Screen; label: string; Icon: (p: { c?: string }) => React.ReactElement; fab?: true }
  const items: NavItem[] = [
    { id: 'home', label: 'Home', Icon: Ic.Home },
    { id: 'reports', label: 'Reports', Icon: Ic.Chart },
    { id: 'home', label: '', Icon: Ic.Plus, fab: true },
    { id: 'budgets', label: 'Budget', Icon: Ic.Wallet },
    { id: 'profile', label: 'Profile', Icon: Ic.User },
  ]
  return (
    <div style={{
      height: 72, display: 'flex', alignItems: 'center',
      background: C.surface, borderTop: `1px solid ${C.border}`,
      flexShrink: 0, paddingBottom: 8,
    }}>
      {items.map((item, idx) => {
        const isFab = !!item.fab
        const active = !isFab && screen === item.id
        return (
          <button key={idx} onClick={() => isFab ? nav('add-tx') : goTab(item.id)}
            style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
              gap: isFab ? 0 : 3, background: 'none', border: 'none', cursor: 'pointer',
              paddingTop: isFab ? 0 : 6, position: 'relative',
            }}>
            {isFab ? (
              <div style={{
                width: 50, height: 50, borderRadius: '50%',
                background: 'linear-gradient(135deg, var(--c-primary), var(--c-primary-dark))',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 6px 18px var(--c-primary-shadow)',
                position: 'absolute', top: -20,
              }}>
                <Ic.Plus />
              </div>
            ) : (
              <>
                <item.Icon c={active ? C.green : C.textDim} />
                <span style={{ fontSize: 10, fontWeight: active ? 700 : 500, color: active ? C.green : C.textDim }}>{item.label}</span>
                {active && <div style={{ position: 'absolute', bottom: -8, width: 18, height: 2.5, borderRadius: 99, background: C.green }} />}
              </>
            )}
          </button>
        )
      })}
    </div>
  )
}

// ─── Screen: Login ────────────────────────────────────────────────────────────
function LoginScreen({ onLogin, onSignup }: { onLogin: () => void; onSignup: () => void }) {
  const [email, setEmail] = useState('maya@example.com')
  const [pass, setPass] = useState('')
  const [show, setShow] = useState(false)
  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', minHeight: '100%', background: C.surface }}>
      <div style={{ marginTop: 32, marginBottom: 40 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 28 }}>
          <div style={{ width: 42, height: 42, borderRadius: 14, background: C.green, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🌿</div>
          <span style={{ fontSize: 22, fontWeight: 800, color: C.text }}>Finflow</span>
        </div>
        <h1 style={{ margin: '0 0 8px', fontSize: 28, fontWeight: 800, letterSpacing: '-0.5px' }}>Welcome back</h1>
        <p style={{ margin: 0, fontSize: 14, color: C.textSub, fontWeight: 500 }}>Sign in to manage your finances</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <MInput label="Email address" type="email" placeholder="your@email.com" value={email} onChange={setEmail} />
        <MInput label="Password" type={show ? 'text' : 'password'} placeholder="••••••••" value={pass} onChange={setPass}
          right={
            <button onClick={() => setShow(!show)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 16, color: C.textDim, padding: 0, lineHeight: 1 }}>
              {show ? '🙈' : '👁️'}
            </button>
          }
        />
        <div style={{ textAlign: 'right' }}>
          <span style={{ fontSize: 13, color: C.green, fontWeight: 600, cursor: 'pointer' }}>Forgot password?</span>
        </div>
        <MBtn onClick={onLogin} full>Sign In</MBtn>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '22px 0' }}>
        <div style={{ flex: 1, height: 1, background: C.border }} />
        <span style={{ fontSize: 12, color: C.textDim, fontWeight: 500 }}>or continue with</span>
        <div style={{ flex: 1, height: 1, background: C.border }} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {[{ icon: 'G', label: 'Google' }, { icon: '🍎', label: 'Apple' }].map(s => (
          <button key={s.label} style={{
            padding: '12px', background: C.surface, border: `1.5px solid ${C.border}`, borderRadius: 12,
            fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            fontFamily: 'Manrope, sans-serif', color: C.text,
          }}>
            <span style={{ fontWeight: 800 }}>{s.icon}</span> {s.label}
          </button>
        ))}
      </div>

      <div style={{ marginTop: 'auto', textAlign: 'center', paddingTop: 28 }}>
        <span style={{ fontSize: 14, color: C.textSub }}>Don't have an account? </span>
        <span onClick={onSignup} style={{ fontSize: 14, color: C.green, fontWeight: 700, cursor: 'pointer' }}>Sign Up</span>
      </div>
    </div>
  )
}

// ─── Screen: Signup ───────────────────────────────────────────────────────────
function SignupScreen({ back, onSignup }: { back: () => void; onSignup: () => void }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [agreed, setAgreed] = useState(false)
  return (
    <div style={{ background: C.surface, minHeight: '100%' }}>
      <MHeader title="Create Account" back={back} />
      <div style={{ padding: '24px 20px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <p style={{ margin: 0, fontSize: 14, color: C.textSub, fontWeight: 500 }}>Join Finflow and take control of your finances</p>
        <MInput label="Full name" placeholder="Maya Chen" value={name} onChange={setName} />
        <MInput label="Email address" type="email" placeholder="your@email.com" value={email} onChange={setEmail} />
        <MInput label="Password" type="password" placeholder="Minimum 8 characters" value={pass} onChange={setPass} />

        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginTop: 4 }}>
          <div onClick={() => setAgreed(!agreed)} style={{
            width: 20, height: 20, borderRadius: 6, border: `2px solid ${agreed ? C.green : C.border}`,
            background: agreed ? C.green : 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 2,
          }}>
            {agreed && <Ic.Check />}
          </div>
          <span style={{ fontSize: 13, color: C.textSub, lineHeight: 1.5 }}>
            I agree to the <span style={{ color: C.green, fontWeight: 600 }}>Terms of Service</span> and{' '}
            <span style={{ color: C.green, fontWeight: 600 }}>Privacy Policy</span>
          </span>
        </div>

        <MBtn onClick={onSignup} full>Create Account</MBtn>

        <div style={{ textAlign: 'center' }}>
          <span style={{ fontSize: 14, color: C.textSub }}>Already have an account? </span>
          <span onClick={back} style={{ fontSize: 14, color: C.green, fontWeight: 700, cursor: 'pointer' }}>Sign In</span>
        </div>
      </div>
    </div>
  )
}

// ─── Screen: Home ─────────────────────────────────────────────────────────────
function HomeScreen({ nav, selectTx }: { nav: (s: Screen) => void; selectTx: (tx: Transaction) => void }) {
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      {/* Header */}
      <div style={{ background: C.surface, padding: '16px 20px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <p style={{ margin: '0 0 2px', fontSize: 12, color: C.textDim, fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Good morning</p>
          <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>Maya Chen 👋</h2>
        </div>
        <button onClick={() => nav('notifications')} style={{ position: 'relative', background: C.surfaceHigh, border: `1px solid ${C.border}`, borderRadius: 12, width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
          <Ic.Bell />
          <span style={{ position: 'absolute', top: 7, right: 7, width: 7, height: 7, borderRadius: '50%', background: C.red, border: `1.5px solid ${C.surface}` }} />
        </button>
      </div>

      {/* Balance card */}
      <div style={{ padding: '16px 16px 0' }}>
        <div style={{
          background: 'linear-gradient(135deg, var(--c-hero-from) 0%, var(--c-hero-to) 100%)',
          borderRadius: 20, padding: '22px 22px 20px',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: -40, right: -20, width: 160, height: 160, borderRadius: '50%', background: 'radial-gradient(circle, var(--c-hero-glow-primary) 0%, transparent 65%)', pointerEvents: 'none' }} />
          <div style={{ position: 'absolute', bottom: -50, left: -10, width: 130, height: 130, borderRadius: '50%', background: 'radial-gradient(circle, var(--c-hero-glow-blue) 0%, transparent 65%)', pointerEvents: 'none' }} />

          <p style={{ margin: '0 0 6px', fontSize: 12, color: 'rgba(255,255,255,0.5)', fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Total Balance</p>
          <p style={{ margin: '0 0 22px', fontSize: 38, fontWeight: 800, color: '#fff', letterSpacing: '-1.5px', fontVariantNumeric: 'tabular-nums' }}>$24,390<span style={{ fontSize: 22, fontWeight: 600, color: 'rgba(255,255,255,0.6)' }}>.18</span></p>

          <div style={{ display: 'flex', gap: 0 }}>
            {[
              { label: 'Income', value: '+$6,050', color: '#4ade80' },
              { label: 'Expenses', value: '-$3,284', color: '#f87171' },
              { label: 'Saved', value: '$2,766', color: 'rgba(255,255,255,0.8)' },
            ].map((s, i) => (
              <div key={s.label} style={{ flex: 1, borderLeft: i > 0 ? '1px solid rgba(255,255,255,0.1)' : 'none', paddingLeft: i > 0 ? 14 : 0 }}>
                <p style={{ margin: '0 0 3px', fontSize: 10, color: 'rgba(255,255,255,0.4)', fontWeight: 600 }}>{s.label}</p>
                <p style={{ margin: 0, fontSize: 14, fontWeight: 700, color: s.color, fontVariantNumeric: 'tabular-nums' }}>{s.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div style={{ padding: '16px 16px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          {[
            { label: 'Send', icon: '↗', color: C.green, bg: C.greenDim },
            { label: 'Receive', icon: '↙', color: C.blue, bg: C.blueDim },
            { label: 'Scan', icon: '⊡', color: C.amber, bg: C.amberDim, action: 'scan' as Screen },
            { label: 'History', icon: '≡', color: C.violet, bg: C.violetDim },
          ].map(a => (
            <button key={a.label} onClick={() => a.action && nav(a.action)} style={{
              background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14,
              padding: '12px 6px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7,
            }}>
              <div style={{ width: 38, height: 38, borderRadius: 12, background: a.bg, color: a.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 700 }}>{a.icon}</div>
              <span style={{ fontSize: 11, fontWeight: 700, color: C.textSub }}>{a.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Mini chart */}
      <div style={{ padding: '16px 16px 0' }}>
        <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border}`, padding: '16px 16px 10px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>Spending trend</p>
            <Tag color={C.green} bg={C.greenDim}>This week</Tag>
          </div>
          <ResponsiveContainer width="100%" height={80}>
            <AreaChart data={weeklyData} margin={{ top: 0, right: 0, bottom: 0, left: -30 }}>
              <defs>
                <linearGradient id="spkGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.green} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={C.green} stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" tick={{ fontSize: 9, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 12 }} formatter={(v: unknown) => [`$${Number(v)}`, 'Spent']} />
              <Area type="monotone" dataKey="amount" stroke={C.green} strokeWidth={2} fill="url(#spkGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent transactions */}
      <div style={{ padding: '16px 16px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <p style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>Recent Transactions</p>
          <span style={{ fontSize: 12, color: C.green, fontWeight: 600, cursor: 'pointer' }}>See all</span>
        </div>
        <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border}`, overflow: 'hidden' }}>
          {transactions.slice(0, 5).map((tx) => (
            <TxRow key={tx.id} tx={tx} onPress={() => selectTx(tx)} />
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Screen: Notifications ────────────────────────────────────────────────────
function NotificationsScreen({ back }: { back: () => void }) {
  const [items, setItems] = useState(notifications)
  const markAll = () => setItems(prev => prev.map(n => ({ ...n, read: true })))
  const typeIcon = { alert: '⚠️', info: 'ℹ️', success: '✅' }
  const typeBg = { alert: C.amberDim, info: C.blueDim, success: C.greenDim }
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      <MHeader title="Notifications" back={back}
        right={<span onClick={markAll} style={{ fontSize: 12, color: C.green, fontWeight: 700, cursor: 'pointer' }}>Mark all read</span>}
      />
      <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {items.map(n => (
          <div key={n.id} style={{
            background: C.surface, borderRadius: 14, padding: '14px 16px',
            border: `1px solid ${n.read ? C.border : 'var(--c-success-border)'}`,
            display: 'flex', gap: 12, alignItems: 'flex-start',
          }}>
            <div style={{ width: 36, height: 36, borderRadius: 12, background: typeBg[n.type], display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>
              {typeIcon[n.type]}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 3 }}>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>{n.title}</p>
                {!n.read && <div style={{ width: 7, height: 7, borderRadius: '50%', background: C.green, flexShrink: 0, marginTop: 3 }} />}
              </div>
              <p style={{ margin: '0 0 4px', fontSize: 12, color: C.textSub, lineHeight: 1.4 }}>{n.message}</p>
              <p style={{ margin: 0, fontSize: 11, color: C.textDim, fontWeight: 500 }}>{n.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Screen: Scan ─────────────────────────────────────────────────────────────
function ScanScreen({ back, nav }: { back: () => void; nav: (s: Screen) => void }) {
  const [scanned, setScanned] = useState(false)
  return (
    <div style={{ background: 'var(--c-scan-surface)', minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '16px 20px', background: 'var(--c-scan-surface)' }}>
        <button onClick={back} style={{ background: 'rgba(255,255,255,0.1)', border: 'none', borderRadius: 10, width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
        </button>
        <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: '#fff' }}>Scan Barcode</h2>
      </div>

      {/* Viewfinder */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <div style={{ position: 'relative', width: 260, height: 200 }}>
          {/* Corner marks */}
          {[['top', 'left'], ['top', 'right'], ['bottom', 'left'], ['bottom', 'right']].map(([v, h]) => (
            <div key={`${v}${h}`} style={{
              position: 'absolute', [v]: 0, [h]: 0,
              width: 28, height: 28,
              borderTop: v === 'top' ? `3px solid ${C.green}` : 'none',
              borderBottom: v === 'bottom' ? `3px solid ${C.green}` : 'none',
              borderLeft: h === 'left' ? `3px solid ${C.green}` : 'none',
              borderRight: h === 'right' ? `3px solid ${C.green}` : 'none',
              borderRadius: h === 'left' && v === 'top' ? '8px 0 0 0' : h === 'right' && v === 'top' ? '0 8px 0 0' : h === 'left' && v === 'bottom' ? '0 0 0 8px' : '0 0 8px 0',
            }} />
          ))}
          {/* Scan line */}
          <div style={{ position: 'absolute', top: '40%', left: 10, right: 10, height: 2, background: `linear-gradient(90deg, transparent, ${C.green}, transparent)`, boxShadow: `0 0 8px ${C.green}`, animation: 'none' }} />
          {/* Barcode visual */}
          <div style={{ position: 'absolute', inset: 20, display: 'flex', alignItems: 'center', gap: 2, padding: '20px 10px', opacity: 0.3 }}>
            {Array.from({ length: 28 }).map((_, i) => (
              <div key={i} style={{ flex: [1, 2, 1, 3, 1, 2, 1, 1, 2, 1, 3, 1, 2, 1, 1, 2, 3, 1, 2, 1, 1, 3, 2, 1, 1, 2, 1, 2][i] || 1, height: '100%', background: '#fff', borderRadius: 1 }} />
            ))}
          </div>
        </div>
      </div>

      <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.5)', fontSize: 13, fontWeight: 500, margin: '0 0 20px' }}>Point camera at a product barcode</p>

      <div style={{ padding: '0 20px 28px', display: 'flex', gap: 10 }}>
        <button onClick={() => { setScanned(true); setTimeout(() => nav('add-tx'), 600) }} style={{
          flex: 1, padding: '14px', background: C.green, color: '#fff', border: 'none', borderRadius: 14,
          fontSize: 14, fontWeight: 700, cursor: 'pointer', fontFamily: 'Manrope, sans-serif',
        }}>
          {scanned ? '✓ Scanned!' : 'Simulate Scan'}
        </button>
        <button onClick={() => nav('add-tx')} style={{
          padding: '14px 18px', background: 'rgba(255,255,255,0.1)', color: '#fff', border: 'none', borderRadius: 14,
          fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'Manrope, sans-serif',
        }}>Manual</button>
      </div>
    </div>
  )
}

// ─── Screen: Add Transaction ──────────────────────────────────────────────────
function AddTxScreen({ back }: { back: () => void }) {
  const [type, setType] = useState<'expense' | 'income'>('expense')
  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')
  const [cat, setCat] = useState('Groceries')
  const cats = ['Groceries', 'Dining', 'Transport', 'Entertainment', 'Health', 'Shopping', 'Utilities', 'Income']
  const catIcons: Record<string, string> = { Groceries: '🛒', Dining: '🍽️', Transport: '🚌', Entertainment: '🎬', Health: '💪', Shopping: '🛍️', Utilities: '⚡', Income: '💼' }
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      <MHeader title="Add Transaction" back={back} />
      <div style={{ padding: '20px 16px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Type toggle */}
        <div style={{ display: 'flex', background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: 4, gap: 4 }}>
          {(['expense', 'income'] as const).map(t => (
            <button key={t} onClick={() => setType(t)} style={{
              flex: 1, padding: '10px', borderRadius: 11, border: 'none', cursor: 'pointer',
              background: type === t ? (t === 'expense' ? C.red : C.green) : 'transparent',
              color: type === t ? '#fff' : C.textDim,
              fontSize: 13, fontWeight: 700, fontFamily: 'Manrope, sans-serif',
              transition: 'all 0.2s',
            }}>
              {t === 'expense' ? '↑ Expense' : '↓ Income'}
            </button>
          ))}
        </div>

        {/* Amount */}
        <div style={{ background: C.surface, borderRadius: 16, padding: '24px', textAlign: 'center', border: `1px solid ${C.border}` }}>
          <p style={{ margin: '0 0 8px', fontSize: 12, color: C.textDim, fontWeight: 600 }}>Amount</p>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
            <span style={{ fontSize: 28, fontWeight: 700, color: C.textSub }}>$</span>
            <input type="number" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)}
              style={{
                fontSize: 44, fontWeight: 800, color: type === 'expense' ? C.red : C.green,
                border: 'none', background: 'transparent', outline: 'none', width: 160, textAlign: 'center',
                fontFamily: 'JetBrains Mono, monospace', fontVariantNumeric: 'tabular-nums',
              }}
            />
          </div>
        </div>

        {/* Category */}
        <div>
          <p style={{ margin: '0 0 10px', fontSize: 12, fontWeight: 600, color: C.textSub }}>Category</p>
          <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
            {cats.map(c => (
              <button key={c} onClick={() => setCat(c)} style={{
                flexShrink: 0, display: 'flex', alignItems: 'center', gap: 6,
                padding: '8px 14px', borderRadius: 99,
                background: cat === c ? C.green : C.surface,
                border: `1.5px solid ${cat === c ? C.green : C.border}`,
                color: cat === c ? '#fff' : C.textSub,
                fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'Manrope, sans-serif',
              }}>
                <span>{catIcons[c]}</span> {c}
              </button>
            ))}
          </div>
        </div>

        <MInput label="Note (optional)" placeholder="e.g. Weekly groceries at Whole Foods" value={note} onChange={setNote} />
        <MInput label="Date" type="date" value="2026-08-01" onChange={() => {}} />

        <MBtn onClick={back} full>
          {type === 'expense' ? '↑' : '↓'} Add {type === 'expense' ? 'Expense' : 'Income'}
        </MBtn>
      </div>
    </div>
  )
}

// ─── Screen: Transaction Detail ───────────────────────────────────────────────
function TxDetailScreen({ back, tx }: { back: () => void; tx: Transaction | null }) {
  if (!tx) return null
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      <MHeader title="Transaction Details" back={back} right={<button style={{ background: 'none', border: 'none', cursor: 'pointer' }}><Ic.Edit /></button>} />
      <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* Hero */}
        <div style={{ background: C.surface, borderRadius: 20, padding: '28px 20px', textAlign: 'center', border: `1px solid ${C.border}` }}>
          <div style={{ width: 64, height: 64, borderRadius: 20, background: `${tx.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, margin: '0 auto 14px' }}>{tx.icon}</div>
          <p style={{ margin: '0 0 6px', fontSize: 18, fontWeight: 700 }}>{tx.name}</p>
          <p style={{ margin: '0 0 16px', fontSize: 36, fontWeight: 800, color: tx.type === 'income' ? C.income : C.red, letterSpacing: '-1px', fontVariantNumeric: 'tabular-nums' }}>
            {tx.type === 'income' ? '+' : '−'}${Math.abs(tx.amount).toFixed(2)}
          </p>
          <Tag color={tx.type === 'income' ? C.income : C.amber} bg={tx.type === 'income' ? C.incomeDim : C.amberDim}>
            {tx.category}
          </Tag>
        </div>

        {/* Details */}
        <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border}`, overflow: 'hidden' }}>
          {[
            { label: 'Date', value: tx.date },
            { label: 'Type', value: tx.type === 'income' ? 'Income' : 'Expense' },
            { label: 'Category', value: tx.category },
            { label: 'Note', value: tx.note || 'No note added' },
            { label: 'Reference', value: `#TXN-${tx.id.padStart(6, '0')}` },
          ].map((d, i, arr) => (
            <div key={d.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '13px 18px', borderBottom: i < arr.length - 1 ? `1px solid ${C.border}` : 'none' }}>
              <span style={{ fontSize: 13, color: C.textSub, fontWeight: 500 }}>{d.label}</span>
              <span style={{ fontSize: 13, fontWeight: 600, fontFamily: d.label === 'Reference' ? 'JetBrains Mono, monospace' : 'Manrope, sans-serif' }}>{d.value}</span>
            </div>
          ))}
        </div>

        <MBtn variant="danger" full onClick={back}>Delete Transaction</MBtn>
      </div>
    </div>
  )
}

// ─── Screen: Categories ───────────────────────────────────────────────────────
function CategoriesScreen({ back }: { back: () => void }) {
  const cats = [
    { name: 'Groceries', icon: '🛒', color: C.amber, spent: 284, budget: 400 },
    { name: 'Dining Out', icon: '🍽️', color: C.violet, spent: 178, budget: 200 },
    { name: 'Entertainment', icon: '🎬', color: C.amber, spent: 63, budget: 80 },
    { name: 'Health', icon: '💪', color: C.blue, spent: 45, budget: 120 },
    { name: 'Shopping', icon: '🛍️', color: C.teal, spent: 237, budget: 300 },
    { name: 'Transport', icon: '🚌', color: C.slate, spent: 68, budget: 150 },
    { name: 'Utilities', icon: '⚡', color: C.red, spent: 62, budget: 100 },
    { name: 'Income', icon: '💼', color: C.green, spent: 6050, budget: 0 },
  ]
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      <MHeader title="Categories" back={back} />
      <div style={{ padding: '12px 16px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {cats.map(c => (
          <div key={c.name} style={{ background: C.surface, borderRadius: 16, padding: 16, border: `1px solid ${C.border}` }}>
            <div style={{ width: 44, height: 44, borderRadius: 14, background: `${c.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, marginBottom: 12 }}>{c.icon}</div>
            <p style={{ margin: '0 0 3px', fontSize: 13, fontWeight: 700 }}>{c.name}</p>
            <p style={{ margin: '0 0 10px', fontSize: 16, fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>${c.spent.toLocaleString()}</p>
            {c.budget > 0 && (
              <>
                <ProgressBar pct={(c.spent / c.budget) * 100} color={c.color} />
                <p style={{ margin: '5px 0 0', fontSize: 10, color: C.textDim, fontWeight: 500 }}>${c.budget - c.spent} left of ${c.budget}</p>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Screen: Budgets ─────────────────────────────────────────────────────────
function BudgetsScreen({ back }: { back: () => void }) {
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      <MHeader title="Budgets" back={back}
        right={<button style={{ background: C.greenDim, border: 'none', borderRadius: 10, padding: '6px 12px', fontSize: 12, fontWeight: 700, color: C.green, cursor: 'pointer', fontFamily: 'Manrope, sans-serif' }}>+ Add</button>}
      />
      {/* Summary */}
      <div style={{ padding: '12px 16px' }}>
        <div style={{ background: 'linear-gradient(135deg, var(--c-success-bg-from), var(--c-success-bg-to))', borderRadius: 16, padding: '16px', border: '1px solid var(--c-success-border)', display: 'flex', gap: 16, marginBottom: 4 }}>
          <div style={{ flex: 1 }}>
            <p style={{ margin: '0 0 3px', fontSize: 11, color: 'var(--c-success-text)', fontWeight: 600 }}>Monthly Total</p>
            <p style={{ margin: 0, fontSize: 22, fontWeight: 800, color: 'var(--c-success-text-bold)', fontVariantNumeric: 'tabular-nums' }}>$1,350</p>
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ margin: '0 0 3px', fontSize: 11, color: 'var(--c-success-text)', fontWeight: 600 }}>Budget Limit</p>
            <p style={{ margin: 0, fontSize: 22, fontWeight: 800, color: 'var(--c-success-text-bold)', fontVariantNumeric: 'tabular-nums' }}>$1,850</p>
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ margin: '0 0 3px', fontSize: 11, color: 'var(--c-success-text)', fontWeight: 600 }}>Remaining</p>
            <p style={{ margin: 0, fontSize: 22, fontWeight: 800, color: 'var(--c-success-accent)', fontVariantNumeric: 'tabular-nums' }}>$500</p>
          </div>
        </div>
      </div>

      <div style={{ padding: '0 16px 24px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {budgets.map(b => {
          const pct = (b.spent / b.total) * 100
          const over = pct >= 90
          return (
            <div key={b.id} style={{ background: C.surface, borderRadius: 16, padding: '16px', border: `1px solid ${over ? 'rgba(220,38,38,0.3)' : C.border}` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: `${b.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>{b.icon}</div>
                <div style={{ flex: 1 }}>
                  <p style={{ margin: '0 0 2px', fontSize: 14, fontWeight: 700 }}>{b.category}</p>
                  <p style={{ margin: 0, fontSize: 12, color: C.textDim }}>Monthly budget</p>
                </div>
                {over && <Tag color={C.red} bg={C.redDim}>Alert</Tag>}
              </div>
              <ProgressBar pct={pct} color={b.color} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 7 }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: over ? C.red : C.textSub, fontVariantNumeric: 'tabular-nums' }}>${b.spent} spent</span>
                <span style={{ fontSize: 12, fontWeight: 500, color: C.textDim, fontVariantNumeric: 'tabular-nums' }}>${b.total - b.spent} left of ${b.total}</span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ─── Screen: Monthly Summary ──────────────────────────────────────────────────
function MonthlyScreen({ back }: { back: () => void }) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug']
  const [sel, setSel] = useState('Jul')
  const data = { Jan: { income: 5800, exp: 3200 }, Feb: { income: 6100, exp: 3600 }, Mar: { income: 5900, exp: 3100 }, Apr: { income: 6300, exp: 3800 }, May: { income: 6000, exp: 3300 }, Jun: { income: 6200, exp: 3500 }, Jul: { income: 6050, exp: 3284 }, Aug: { income: 6400, exp: 3200 } }
  const d = data[sel as keyof typeof data]
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      <MHeader title="Monthly Summary" back={back} />
      {/* Month picker */}
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '12px 16px', scrollbarWidth: 'none' }}>
        {months.map(m => (
          <button key={m} onClick={() => setSel(m)} style={{
            flexShrink: 0, padding: '8px 16px', borderRadius: 99,
            background: sel === m ? C.green : C.surface,
            border: `1.5px solid ${sel === m ? C.green : C.border}`,
            color: sel === m ? '#fff' : C.textSub,
            fontSize: 13, fontWeight: 700, cursor: 'pointer', fontFamily: 'Manrope, sans-serif',
          }}>{m} 2026</button>
        ))}
      </div>

      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* KPIs */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          {[
            { label: 'Income', value: `$${d.income.toLocaleString()}`, color: C.green, bg: C.greenDim },
            { label: 'Expenses', value: `$${d.exp.toLocaleString()}`, color: C.red, bg: C.redDim },
            { label: 'Saved', value: `$${(d.income - d.exp).toLocaleString()}`, color: C.blue, bg: C.blueDim },
          ].map(k => (
            <div key={k.label} style={{ background: C.surface, borderRadius: 14, padding: '14px 12px', border: `1px solid ${C.border}`, textAlign: 'center' }}>
              <p style={{ margin: '0 0 4px', fontSize: 10, color: C.textDim, fontWeight: 600 }}>{k.label}</p>
              <p style={{ margin: 0, fontSize: 16, fontWeight: 800, color: k.color, fontVariantNumeric: 'tabular-nums' }}>{k.value}</p>
            </div>
          ))}
        </div>

        {/* Chart */}
        <div style={{ background: C.surface, borderRadius: 16, padding: '16px 16px 10px', border: `1px solid ${C.border}` }}>
          <p style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 700 }}>Income vs Expenses</p>
          <ResponsiveContainer width="100%" height={130}>
            <BarChart data={monthlyData.filter(m => months.indexOf(m.month) <= months.indexOf(sel))} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="2 4" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 9, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 9, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 11 }} formatter={(v: unknown) => [`$${Number(v).toLocaleString()}`, '']} />
              <Bar dataKey="income" fill={C.green} radius={[4, 4, 0, 0]} />
              <Bar dataKey="expenses" fill={C.blue} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Top categories */}
        <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border}`, overflow: 'hidden' }}>
          <p style={{ margin: 0, padding: '14px 18px', fontSize: 13, fontWeight: 700, borderBottom: `1px solid ${C.border}` }}>Top Categories</p>
          {[
            { name: 'Groceries', icon: '🛒', amount: 284, color: C.amber },
            { name: 'Shopping', icon: '🛍️', amount: 237, color: C.teal },
            { name: 'Dining', icon: '🍽️', amount: 178, color: C.violet },
          ].map((c, i, arr) => (
            <div key={c.name} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 18px', borderBottom: i < arr.length - 1 ? `1px solid ${C.border}` : 'none' }}>
              <span style={{ fontSize: 18 }}>{c.icon}</span>
              <span style={{ flex: 1, fontSize: 13, fontWeight: 600 }}>{c.name}</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: c.color, fontVariantNumeric: 'tabular-nums' }}>${c.amount}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Screen: Reports ──────────────────────────────────────────────────────────
function ReportsScreen({ back }: { back: () => void }) {
  const [period, setPeriod] = useState<'W' | 'M' | 'Y'>('M')
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      <MHeader title="Reports" back={back} />
      <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ display: 'flex', background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: 4, gap: 4 }}>
          {(['W', 'M', 'Y'] as const).map(p => (
            <button key={p} onClick={() => setPeriod(p)} style={{
              flex: 1, padding: '8px', borderRadius: 9, border: 'none', cursor: 'pointer',
              background: period === p ? C.green : 'transparent',
              color: period === p ? '#fff' : C.textDim,
              fontSize: 12, fontWeight: 700, fontFamily: 'Manrope, sans-serif', transition: 'all 0.2s',
            }}>
              {p === 'W' ? 'Week' : p === 'M' ? 'Month' : 'Year'}
            </button>
          ))}
        </div>

        <div style={{ background: C.surface, borderRadius: 16, padding: '16px 16px 10px', border: `1px solid ${C.border}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
            <div>
              <p style={{ margin: '0 0 3px', fontSize: 12, color: C.textDim, fontWeight: 500 }}>Total Spent</p>
              <p style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: '-0.5px', fontVariantNumeric: 'tabular-nums' }}>$3,284</p>
            </div>
            <Tag color={C.green} bg={C.greenDim}>↓ 3.1%</Tag>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={monthlyData} margin={{ top: 10, right: 0, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="repGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.blue} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={C.blue} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 4" stroke={C.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 9, fill: C.textDim }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 9, fill: C.textDim }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}k`} />
              <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 11 }} formatter={(v: unknown) => [`$${Number(v).toLocaleString()}`, 'Expenses']} />
              <Area type="monotone" dataKey="expenses" stroke={C.blue} strokeWidth={2} fill="url(#repGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Stat row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {[
            { label: 'Avg. Daily', value: '$106', color: C.text },
            { label: 'Highest Day', value: '$214', color: C.red },
            { label: 'Savings Rate', value: '45.7%', color: C.green },
            { label: 'vs Last Month', value: '−3.1%', color: C.green },
          ].map(s => (
            <div key={s.label} style={{ background: C.surface, borderRadius: 14, padding: 16, border: `1px solid ${C.border}` }}>
              <p style={{ margin: '0 0 5px', fontSize: 11, color: C.textDim, fontWeight: 600 }}>{s.label}</p>
              <p style={{ margin: 0, fontSize: 22, fontWeight: 800, color: s.color, fontVariantNumeric: 'tabular-nums' }}>{s.value}</p>
            </div>
          ))}
        </div>

        {/* Top spending */}
        <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border}`, overflow: 'hidden', marginBottom: 20 }}>
          <p style={{ margin: 0, padding: '14px 18px', fontSize: 13, fontWeight: 700, borderBottom: `1px solid ${C.border}` }}>Top Spending</p>
          {transactions.filter(t => t.type === 'expense').slice(0, 4).map((tx, i, arr) => (
            <TxRow key={tx.id} tx={tx} />
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Screen: Profile ─────────────────────────────────────────────────────────
function ProfileScreen({ back, nav }: { back: () => void; nav: (s: Screen) => void }) {
  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      {/* Header */}
      <div style={{ background: C.surface, padding: '20px 20px 24px', textAlign: 'center', borderBottom: `1px solid ${C.border}` }}>
        <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'linear-gradient(135deg, var(--c-primary), var(--c-primary-dark))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, margin: '0 auto 12px', boxShadow: `0 0 0 4px ${C.greenDim}` }}>👤</div>
        <h2 style={{ margin: '0 0 4px', fontSize: 20, fontWeight: 800 }}>Maya Chen</h2>
        <p style={{ margin: '0 0 12px', fontSize: 13, color: C.textSub, fontWeight: 500 }}>maya@example.com</p>
        <Tag color={C.green} bg={C.greenDim}>✦ Premium Member</Tag>
      </div>

      {/* Stats */}
      <div style={{ padding: 16 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 12 }}>
          {[
            { label: 'Transactions', value: '342' },
            { label: 'Budgets', value: '6' },
            { label: 'Saved', value: '$12K' },
          ].map(s => (
            <div key={s.label} style={{ background: C.surface, borderRadius: 14, padding: '14px 10px', border: `1px solid ${C.border}`, textAlign: 'center' }}>
              <p style={{ margin: '0 0 4px', fontSize: 18, fontWeight: 800 }}>{s.value}</p>
              <p style={{ margin: 0, fontSize: 10, color: C.textDim, fontWeight: 600 }}>{s.label}</p>
            </div>
          ))}
        </div>

        {[
          { label: 'Account & Security', icon: '🔐', items: ['Edit Profile', 'Change Password', 'Two-Factor Auth'] },
          { label: 'Preferences', icon: '⚙️', items: ['Notifications', 'Currency & Language', 'Dark Mode'] },
        ].map(group => (
          <div key={group.label} style={{ marginBottom: 12 }}>
            <p style={{ margin: '0 0 8px', fontSize: 12, color: C.textDim, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase', paddingLeft: 4 }}>{group.label}</p>
            <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border}`, overflow: 'hidden' }}>
              {group.items.map((item, i, arr) => (
                <div key={item} onClick={() => nav('settings')} style={{ display: 'flex', alignItems: 'center', padding: '14px 18px', borderBottom: i < arr.length - 1 ? `1px solid ${C.border}` : 'none', cursor: 'pointer' }}>
                  <span style={{ flex: 1, fontSize: 14, fontWeight: 500 }}>{item}</span>
                  <Ic.ChevronRight />
                </div>
              ))}
            </div>
          </div>
        ))}

        <MBtn variant="danger" full onClick={back}>Sign Out</MBtn>
      </div>
    </div>
  )
}

// ─── Screen: Settings ────────────────────────────────────────────────────────
function SettingsScreen({ back }: { back: () => void }) {
  const [notif, setNotif] = useState(true)
  const [biometric, setBiometric] = useState(true)
  const [dark, setDark] = useState(false)
  const [sync, setSync] = useState(true)

  function Toggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
    return (
      <div onClick={onToggle} style={{
        width: 44, height: 26, borderRadius: 99, cursor: 'pointer',
        background: on ? C.green : C.border, transition: 'background 0.2s',
        position: 'relative',
      }}>
        <div style={{
          position: 'absolute', top: 3, left: on ? 21 : 3,
          width: 20, height: 20, borderRadius: '50%', background: '#fff',
          boxShadow: '0 1px 3px rgba(0,0,0,0.15)', transition: 'left 0.2s',
        }} />
      </div>
    )
  }

  const sections = [
    {
      label: 'Notifications',
      items: [
        { label: 'Push Notifications', sub: 'Budget alerts & summaries', toggle: true, on: notif, fn: () => setNotif(!notif) },
        { label: 'Budget Alerts', sub: 'Notify at 80% and 100%', toggle: true, on: true, fn: () => {} },
      ],
    },
    {
      label: 'Security',
      items: [
        { label: 'Biometric Login', sub: 'Fingerprint or Face ID', toggle: true, on: biometric, fn: () => setBiometric(!biometric) },
        { label: 'Auto-lock', sub: '1 minute', toggle: false, on: false, fn: () => {} },
      ],
    },
    {
      label: 'App',
      items: [
        { label: 'Dark Mode', sub: 'System / Light / Dark', toggle: true, on: dark, fn: () => setDark(!dark) },
        { label: 'Cloud Sync', sub: 'Last synced 2 min ago', toggle: true, on: sync, fn: () => setSync(!sync) },
        { label: 'Currency', sub: 'USD — US Dollar', toggle: false, on: false, fn: () => {} },
      ],
    },
    {
      label: 'Data',
      items: [
        { label: 'Export Data', sub: 'Download CSV or PDF', toggle: false, on: false, fn: () => {} },
        { label: 'Clear Cache', sub: '14.2 MB', toggle: false, on: false, fn: () => {} },
      ],
    },
  ]

  return (
    <div style={{ background: C.bg, minHeight: '100%' }}>
      <MHeader title="Settings" back={back} />
      <div style={{ padding: '12px 16px 24px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        {sections.map(sec => (
          <div key={sec.label}>
            <p style={{ margin: '0 0 8px', fontSize: 11, color: C.textDim, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', paddingLeft: 4 }}>{sec.label}</p>
            <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border}`, overflow: 'hidden' }}>
              {sec.items.map((item, i, arr) => (
                <div key={item.label} style={{ display: 'flex', alignItems: 'center', padding: '13px 18px', borderBottom: i < arr.length - 1 ? `1px solid ${C.border}` : 'none', cursor: item.toggle ? 'pointer' : 'default' }}>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: '0 0 2px', fontSize: 14, fontWeight: 600 }}>{item.label}</p>
                    <p style={{ margin: 0, fontSize: 11, color: C.textDim, fontWeight: 500 }}>{item.sub}</p>
                  </div>
                  {item.toggle
                    ? <Toggle on={item.on} onToggle={item.fn} />
                    : <Ic.ChevronRight />}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── MobileApp shell ──────────────────────────────────────────────────────────
export default function MobileApp() {
  const [screen, setScreen] = useState<Screen>('login')
  const [history, setHistory] = useState<Screen[]>([])
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null)

  const nav = (to: Screen) => {
    setHistory(prev => [...prev, screen])
    setScreen(to)
  }
  const back = () => {
    const prev = history[history.length - 1]
    if (prev) { setScreen(prev); setHistory(h => h.slice(0, -1)) }
  }
  const goTab = (to: Screen) => { setScreen(to); setHistory([]) }

  const isMain = MAIN_SCREENS.includes(screen)

  return (
    <div style={{
      width: 390, background: C.surface, borderRadius: 40,
      border: '6px solid var(--c-sidebar)',
      boxShadow: '0 40px 80px rgba(0,0,0,0.25), 0 0 0 1px rgba(255,255,255,0.08)',
      overflow: 'hidden', display: 'flex', flexDirection: 'column',
      height: 820, userSelect: 'none',
    }}>
      <StatusBar />
      <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', minHeight: 0 }}>
        {screen === 'login' && <LoginScreen onLogin={() => goTab('home')} onSignup={() => nav('signup')} />}
        {screen === 'signup' && <SignupScreen back={back} onSignup={() => goTab('home')} />}
        {screen === 'home' && <HomeScreen nav={nav} selectTx={(tx) => { setSelectedTx(tx); nav('tx-detail') }} />}
        {screen === 'notifications' && <NotificationsScreen back={back} />}
        {screen === 'scan' && <ScanScreen back={back} nav={nav} />}
        {screen === 'add-tx' && <AddTxScreen back={back} />}
        {screen === 'tx-detail' && <TxDetailScreen back={back} tx={selectedTx} />}
        {screen === 'categories' && <CategoriesScreen back={back} />}
        {screen === 'budgets' && <BudgetsScreen back={back} />}
        {screen === 'monthly' && <MonthlyScreen back={back} />}
        {screen === 'reports' && <ReportsScreen back={back} />}
        {screen === 'profile' && <ProfileScreen back={back} nav={nav} />}
        {screen === 'settings' && <SettingsScreen back={back} />}
      </div>
      {isMain && <BottomNav screen={screen} goTab={goTab} nav={nav} />}
    </div>
  )
}
